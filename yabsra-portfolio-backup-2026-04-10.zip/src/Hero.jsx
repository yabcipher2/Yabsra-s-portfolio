import { motion } from "framer-motion";
import {
  GitBranch as FaGithub,
  Users as FaLinkedin,
  Mail,
  ArrowRight,
} from "lucide-react";
// Import your photo here. Make sure profile.jpg is in your src/assets folder!
import profileImg from "./assets/profile.png";

const Hero = () => {
  return (
    <section className="hero-wrapper">
      <div className="hero-container hero-flex">
        {/* Left Side: Text Content */}
        <div className="hero-text-content">
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="hero-mono-text"
          >
            Hi, my name is
          </motion.p>

          <motion.h1
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="hero-main-title"
          >
            Yabsra Melaku.
          </motion.h1>

          <motion.h2
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="hero-sub-title"
          >
            I build scalable full-stack solutions.
          </motion.h2>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.6 }}
            className="hero-bio"
          >
            I’m a software engineer specializing in building (and occasionally
            designing) exceptional digital experiences. Currently, I’m focused
            on building accessible, human-centered products with Node.js and
            React.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.8 }}
            className="hero-actions"
          >
            <button className="hero-work-btn">
              Check out my work <ArrowRight size={20} />
            </button>

            <div className="hero-socials">
              <a href="https://github.com/yabcipher22" className="social-icon">
                <FaGithub />
              </a>
              <a href="https://www.linkedin.com/feed/" className="social-icon">
                <FaLinkedin />
              </a>
              <a href="yabmelaku3@gmail.com" className="social-icon">
                <Mail />
              </a>
            </div>
          </motion.div>
        </div>

        {/* Right Side: Profile Image */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="hero-image-container"
        >
          <div className="image-border">
            <img
              src={profileImg}
              alt="Yabsra Melaku"
              className="profile-image"
            />
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Hero;
