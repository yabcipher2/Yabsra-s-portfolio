import Hero from "./Hero";
import Skills from "./Skills";
import "./index.css";
import Projects from "./Projects";
import Contact from "./Contact";

function App() {
  return (
    <div className="App">
      {/* We use a relative container and a max-height of 100vh here
        to ensure the browser handles the transition between sections nicely.
      */}
      <div style={{ position: "relative", overflowX: "hidden" }}>
        <Hero />
        <Skills />
        <Projects />
        <Contact />
      </div>
    </div>
  );
}

export default App;
