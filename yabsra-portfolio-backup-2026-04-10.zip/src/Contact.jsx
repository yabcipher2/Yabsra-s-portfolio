import { motion } from "framer-motion";
import { Mail, FileText } from "lucide-react";

const Contact = () => {
  return (
    <section id="contact" className="contact-wrapper">
      <motion.div
        className="contact-container"
        initial={{ opacity: 0, scale: 0.9 }}
        whileInView={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.6 }}
        viewport={{ once: true }}
      >
        <p className="contact-mono">04. What's Next?</p>
        <h2 className="contact-title">Get In Touch</h2>
        <p className="contact-desc">
          I’m currently looking for new opportunities as a software developer.
          Whether you have a question about my Android apps or Node.js work, my
          inbox is always open!
        </p>

        <div className="contact-actions">
          <a
            href="mailto:yabmelaku3@gmail.com"
            className="contact-btn email-btn"
          >
            <Mail size={20} /> Say Hello
          </a>

          {/* If you have a PDF CV, put it in the public folder and link it here */}
          <a
            href="/Yabsra_Melaku cv.pdf"
            target="_blank"
            className="contact-btn cv-btn"
          >
            <FileText size={20} /> Download CV
          </a>
        </div>

        <footer className="footer-text">
          Designed & Built by Yabsra Melaku
        </footer>
      </motion.div>
    </section>
  );
};

export default Contact;
