import { motion } from "framer-motion";

const skillData = [
  {
    name: "React",
    icon: "https://raw.githubusercontent.com/devicons/devicon/master/icons/react/react-original.svg",
  },
  {
    name: "Node.js",
    icon: "https://raw.githubusercontent.com/devicons/devicon/master/icons/nodejs/nodejs-original.svg",
  },
  {
    name: "Android Studio",
    icon: "https://raw.githubusercontent.com/devicons/devicon/master/icons/android/android-original.svg",
  },
  {
    name: "Java",
    icon: "https://raw.githubusercontent.com/devicons/devicon/master/icons/java/java-original.svg",
  },
  {
    name: "JavaScript",
    icon: "https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-original.svg",
  },
  {
    name: "MongoDB",
    icon: "https://raw.githubusercontent.com/devicons/devicon/master/icons/mongodb/mongodb-original.svg",
  },
  {
    name: "Vite",
    icon: "https://raw.githubusercontent.com/devicons/devicon/master/icons/vite/vite-original.svg",
  },
];

// Animation variant for standard entry
const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1, // This makes icons appear one by one
    },
  },
};

const skillVariants = {
  hidden: { y: 20, opacity: 0 },
  visible: { y: 0, opacity: 1 },
};

const Skills = () => {
  return (
    <section id="skills" className="skills-wrapper">
      <div className="skills-container">
        <h2 className="section-title">My Technical Stack</h2>
        <motion.div
          className="skills-grid"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible" // Only animate when the section is scrolled into view
          viewport={{ once: true, amount: 0.3 }} // amount: 0.3 means animate when 30% of section is visible
        >
          {skillData.map((skill, index) => (
            <motion.div
              key={index}
              className="skill-card"
              variants={skillVariants}
              whileHover={{ scale: 1.1, y: -5 }} // Add that hover animation
            >
              <img src={skill.icon} alt={skill.name} className="skill-icon" />
              <p className="skill-name">{skill.name}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default Skills;
