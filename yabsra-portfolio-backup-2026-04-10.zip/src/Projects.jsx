import { motion } from "framer-motion";
import { GitBranch as FaGithub } from "lucide-react";
import { ExternalLink } from "lucide-react";

const projectData = [
  {
    title: "CampusNoticeBoard",
    description:
      "A mobile application for real-time campus updates. Built with a focus on local data persistence and a clean UI for students.",
    tech: ["Android Studio", "Java", "Room DB", "SQLite"],
    github: "#",
    demo: "#",
  },
  {
    title: "Full-Stack Web App",
    description:
      "A scalable web solution featuring an Express.js backend and a React frontend with secure user authentication.",
    tech: ["React", "Node.js", "Express", "MongoDB"],
    github: "#",
    demo: "#",
  },
  {
    title: "TCP Echo Server",
    description:
      "High-performance backend utility using Node.js 'net' module and WebAssembly for optimized execution.",
    tech: ["Node.js", "WebAssembly", "JavaScript"],
    github: "#",
    demo: "#",
  },
];

const Projects = () => {
  return (
    <section id="projects" className="projects-wrapper">
      <div className="projects-container">
        <h2 className="section-title">Featured Projects</h2>

        <div className="projects-grid">
          {projectData.map((project, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="project-card"
            >
              <div className="project-header">
                <h3 className="project-title">{project.title}</h3>
                <div className="project-links">
                  <a href={project.github} className="icon-link">
                    <FaGithub size={20} />
                  </a>
                  <a href={project.demo} className="icon-link">
                    <ExternalLink size={20} />
                  </a>
                </div>
              </div>

              <p className="project-desc">{project.description}</p>

              <div className="project-tech-list">
                {project.tech.map((t) => (
                  <span key={t} className="tech-tag">
                    {t}
                  </span>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;
